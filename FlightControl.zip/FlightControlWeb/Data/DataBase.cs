﻿using FlightControlWeb.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;


namespace FlightControlWeb.Data
{
    public class DataBase : DbContext
    {
        //static dictionary data base.
        public Dictionary<string, FlightPlan> fpDictionary = new Dictionary<string, FlightPlan>();
        public Dictionary<string, Flight> fDictionary = new Dictionary<string, Flight>();
        public Dictionary<string, Server> serverDictionary = new Dictionary<string, Server>();
    }
}
