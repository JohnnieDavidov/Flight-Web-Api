﻿// Create map for planes and their ID's.
let icons = new Map();
let flightPlanMap = new Map();
let count = 1;
let blueMark = 0;
let colorMark = "#efeded";
let unMark = '#ffff';
let iStillFlying = false;

// every 3 second update all flights
$(document).ready(function () {
    getAllFlights();
    setInterval(function () {
        getAllFlights();
    }, 3000); 
});

//alert Show
function showAlert(message) {
    document.getElementById("message").innerHTML = message;
    $("#success-alert").fadeTo(10000, 500).slideUp(500, function () {
        $("#success-alert").slideUp(500);
    });
}

// GET/api/Flights?relative_to=<DATE_TIME>&sync_all
function getAllFlights() {
    // get Time
    let tempdate = new Date(Date().toString('en-US', { timeZone: "Etc/GMT-0" }));
    let tmp = tempdate.toISOString();
    let end = tmp.length - 5;
    let date = tmp.substring(0, end);
    date = date + 'Z';
    // request string
    let url = "/api/Flights?relative_to=" + date + "&sync_all";
    //HTTP request by ajax
    $.ajax({
        type: "GET",
        url: url,
        datatype: 'json',
        success: successGetAllFlights,
        error: function () {
            showAlert("Error get flights from server!");
        }
    });
}


function successGetAllFlights(flights) {
    let listLayer = icons.values();
    for (let layer of listLayer) {
        let id = layer.layerID;
        let isIn = id.indexOf("%");
        if (isIn != -1) {
            let end = id.length - 1;
            id = id.substring(0, end);
        }
        isFinished(flights, id);

        // delete finished flights
        finished(id);
        
    }

    // Update or/and add flighte in the tables.
    flights.forEach(function (flight, i) {
        // Get flight id.
        let idFlight = flight.flight_Id;

        // Get flight current location.
        let longitude = flight.longitude;
        let latitude = flight.latitude;

        if (!icons.has(idFlight)) {
            // Create airplains icons.
            let layer = L.marker([latitude, longitude], { icon: airplane1 });
            layer.layerID = idFlight;
            let layer1 = L.marker([latitude, longitude], { icon: airplane2 });
            layer1.layerID = idFlight + "%";

            // Add to icons.
            icons.set(idFlight, layer);
            icons.set(idFlight + "%", layer1);
            if (!flight.is_External) {
                $('#InnerFlight').append('<tr id="' + idFlight + '"><td onClick="showChosenFlight(id)" id="' + idFlight + '">' + idFlight + '</td><td onClick="showChosenFlight(id)" id="' + idFlight + '"> '
                    + flight.company_Name + '</td><td id="deleteButton"><a title="Delete" id="' + "deleteRow" + idFlight +
                    '"><i class="fa fa-trash" aria-hidden="true" style="font-size:large;"></i></a></td></tr>');
            } else {
                $('#ExternalFlight').append('<tr onClick="showChosenFlight(id)" id="' + idFlight + '"><td>' + idFlight + '</td><td> '
                    + flight.company_Name + '</td></tr>');
            }

            let x = document.getElementById("deleteRow" + idFlight);
            if (x != null) {
                x.addEventListener("click", function () {
                    deleteRow(idFlight, x);
                });
            }

            // add plane to map.
            addNewPlaneToMap(latitude, longitude, layer, layer1);
        } else {
            let layer = icons.get(idFlight);
            let layer1 = icons.get(idFlight + "%");
            layer.setLatLng([latitude, longitude]);
            layer1.setLatLng([latitude, longitude]);
        }
    });
}

function isFinished(flights, id) {
    iStillFlying = false;
    for (let flight of flights) {
        //Get flight id.
        let idFlight = flight.flight_Id;
        if (id == idFlight) {
            iStillFlying = true;
            break;
        }
    }
}

// POST/api/FlightPlan
function postFlight(jsonString) {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", 'api/FlightPlan', true);

    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.onreadystatechange = function () {
        if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
            // Request finished.
        }
    }
    xhr.send(jsonString);
}

function readFiles() {
    let file = document.getElementById("fileItem").files[0];
    let reader = new FileReader();

    reader.readAsText(file);

    let dataString;
    reader.onload = function () {
        dataString = reader.result.replace('/r', '');
        postFlight(dataString);
    };

    reader.onerror = function () {
        alert(reader.error);
    };
}

// GET/api/Flights?relative_to=<DATE_TIME>
function getFlights() {
    // Change time to correct format.
    let d = new Date(Date().toString('en-US', { timeZone: "Etc/GMT-0" }));
    let piece = d.toISOString();
    let end = piece.length - 5;
    let date = piece.substring(0, end);
    date = date + 'Z';
    let url = "/api/Flights?relative_to=" + date;

    $.ajax({
        type: "GET",
        url: url,
        datatype: 'json',
        success: successGetFlights,
        error: function () {
            alert("Error getFlights");
        }
    });
}

function successGetFlights(flights) {
    flights.forEach(function (flight, i) {
        // Get flight id.
        let idFlight = flight.flight_Id;

        // Get flight current location.
        let longitude = flight.longitude;
        let latitude = flight.latitude;

        if (!icons.has(idFlight)) {
            // Create airplains icons.
            let layer = L.marker([latitude, longitude], { icon: airplane1 });
            layer.layerID = idFlight;
            let layer1 = L.marker([latitude, longitude], { icon: airplane2 });
            layer1.layerID = idFlight + "%";

            // Add to icons.
            icons.set(idFlight, layer);
            icons.set(idFlight + "%", layer1);
            if (!flight.is_External) {
                $('#InnerFlight').append('<tr id="' + idFlight + '"><td onClick="showChosenFlight(id)" id="' + idFlight + '">' + idFlight + '</td><td onClick="showChosenFlight(id)" id="' + idFlight + '"> '
                    + flight.company_Name + '</td><td id="deleteButton"><button type="button" class="btn" value="Delete" id="' + "deleteRow" + count +
                    '"><span class="fa fa-close"></span><span class="submit - text"> Delete</span></button></td></tr>');
            }
            let x = document.getElementById("deleteRow" + count);
            x.addEventListener("click", function () {
                deleteRow(idFlight, x);
            });
            count = count + 1;

            // add plane to map.
            addNewPlaneToMap(latitude, longitude, layer, layer1);
        } else {
            let layer = icons.get(idFlight);
            let layer1 = icons.get(idFlight + "%");
            layer.setLatLng([latitude, longitude]);
            layer1.setLatLng([latitude, longitude]);
        }
    });
}

function finished(id) {
    if (iStillFlying == false) {
        let x = document.getElementById("deleteRow" + id);
        if (x != null) {
            let i = x.parentNode.parentNode.rowIndex;
            document.getElementById("InnerFlight").deleteRow(i);
        }
        else {
            x = document.getElementById(id);
            let i = x.rowIndex;
            document.getElementById("ExternalFlight").deleteRow(i);
        }
        // Remove plane from map.
        removePlane(id);
        icons.delete(id);
        icons.delete(id + "%");

        // Remove plane path from map.
        // TODO: change when fix this in delete row!!!
        clearMap();
    }
}

// GET/api/FlightPlan/{id}
function getFlightPlan(id) {
    document.getElementById("flightID").textContent = id;
    //update blueMark
    blueMark = id;
    let url = "/api/FlightPlan/" + id;
    $.ajax({
        type: "GET",
        url: url,
        contentType: "applicition/json",
        success: successFlightPlan,
        error: function () {
            alert("Error getFlightPlan");
        }
    });
}

function successFlightPlan(flightPlan) {
    // Show flight details.
    updateDetails(flightPlan);
    addRoute(flightPlan);
}

function updateDetails(item) {
    document.getElementById("Company_name").textContent = item.company_Name;
    document.getElementById("Latitude").textContent = item.initial_Location.latitude.toString();
    document.getElementById("Longitude").textContent = item.initial_Location.longitude.toString();
    document.getElementById("Passengers").textContent = item.passengers;
    if (!item.id) {
        document.getElementById("Is_external").textContent = "Yes";
    } else {
        document.getElementById("Is_external").textContent = "No";
    }
    //calculate end time
    let dateTime = new Date(item.initial_Location.date_Time);
    document.getElementById("init_Date_time").textContent = dateTime.toUTCString();
    let endLocation = document.getElementById("end_Date_time");
    for (let i = 0, seg; seg = item.segments[i]; i++) {
        dateTime.setSeconds(dateTime.getSeconds() + seg.timespan_Seconds);
    }
    document.getElementById("end_Date_time").textContent = dateTime.toUTCString();
}

function deleteFlightDetails(flight_id) {
    document.getElementById("flightID").textContent = "";
    document.getElementById("Company_name").textContent = "";
    document.getElementById("Latitude").textContent = ""
    document.getElementById("Longitude").textContent = "";
    document.getElementById("Passengers").textContent = "";
    document.getElementById("init_Date_time").textContent = "";
    document.getElementById("end_Date_time").textContent = "";
    document.getElementById("Is_external").textContent = "";
    blueMark = 0;
}

// Highlight row after clicking it
let preEl;
let orgBColor;
let orgTColor;
function HighLightTR(el, backColor) {
    let row = document.getElementById(el);
    if (backColor == colorMark) {
        orgBColor = row.bgColor;
        orgTColor = row.style.color;
        row.bgColor = backColor;
        preEl = row
    } else {
        if (typeof (preEl) != 'undefined') {
            preEl.bgColor = orgBColor;
        }
    }

}

// Return the all rows to their original color.
function unMarkTable() {
    if (blueMark != 0) {
        HighLightTR(blueMark, unMark);
    }
}

function showChosenFlight(idFlight) {

    // When click on row of flight - change color.
    unMarkTable();
    unMarkPlan();
    HighLightTR(idFlight, colorMark);
    getFlightPlan(idFlight);

    // Get plane from map and change its color.
    layer = icons.get(idFlight);
    layer1 = icons.get(idFlight + "%");

    changePlaneColor(layer, layer1);
}

function removeShownChosenFlight(idFlight) {
    deleteFlightDetails(idFlight);
    HighLightTR(idFlight, unMark);
    clearMap();
}