﻿
function uploadOnDragOver() {
    document.getElementById("dropState").style.display = "inline";
}

function uploadOnDragLeave() {
    document.getElementById("dropState").style.display = "none";
}
function uploadOnDrop() {
    document.getElementById("dropState").style.display = "none";
    setTimeout(post, 200);
}

function post() {
    let inputFile = document.getElementById("input").files[0];
    let reader = new FileReader();
    reader.readAsText(inputFile);
    let jdata;
    reader.onload = function () {
        jdata = reader.result.replace('/r', '');
        let request = new XMLHttpRequest();
        request.open("POST", "/api/FlightPlan", true);
        request.setRequestHeader("Content-Type", "application/json");
        request.send(jdata);
    }
}

function upload() {
    var fileInput = document.getElementById("real-file");
    let reader = new FileReader();
    if (fileInput.files[0] == null) {
        showAlert("There is no file");
    }
    reader.readAsText(fileInput.files[0]);
    let jdata;
    reader.onload = function () {
        jdata = reader.result.replace('/r', '');
        let request = new XMLHttpRequest();
        request.open("POST", "/api/FlightPlan", true);
        request.setRequestHeader("Content-Type", "application/json");
        request.send(jdata);
    }
}