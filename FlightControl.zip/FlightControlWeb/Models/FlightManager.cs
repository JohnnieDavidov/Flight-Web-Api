﻿using FlightControlWeb.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    public class FlightManager : IFlightManager
    {
        private IFunctionManager fm;
        private DataBase db = new DataBase();
        //constractor
        public FlightManager(FunctionManager func)
        {
            fm = func;
            db = new DataBase();
        }

        public FlightManager(FunctionManager func, DataBase data)
        {
            fm = func;
            db = data;
        }

        public async Task<List<Flight>> GetAllFlight(string relative_to, bool isExternal)
        {
            List<Flight> flights = new List<Flight>();
            DateTime relativeDate = TimeZoneInfo.ConvertTimeToUtc(Convert.ToDateTime(relative_to));
            DateTime flightDate, lastFlightDate;
            List<Segment> flightSegments;
            // Go over all FlightPlans.
            foreach (KeyValuePair<string, FlightPlan> flightPlan in db.fpDictionary)
            {
                lastFlightDate = TimeZoneInfo.ConvertTimeToUtc
                    (Convert.ToDateTime(flightPlan.Value.Initial_Location.Date_Time));
                flightDate = TimeZoneInfo.ConvertTimeToUtc
                    (Convert.ToDateTime(flightPlan.Value.Initial_Location.Date_Time));
                flightSegments = flightPlan.Value.Segments;
                int j = 0;
                if (flightDate > relativeDate)
                {
                    // This Flight didnt started yet.
                    continue;
                }
                // Stop when we are in the segment or there are no more segments.
                while ((flightDate <= relativeDate) && (j < flightSegments.Count))
                {
                    lastFlightDate = flightDate;
                    // Each time- add the timespan seconds of the segments.
                    flightDate = flightDate.AddSeconds(flightSegments[j].Timespan_Seconds);
                    j++;
                }
                // If we are in the segment (the flight didnt finished yet).
                if (flightDate >= relativeDate)
                {
                    // Add flight to list.
                    Flight flight =
                        CreateFlight(relativeDate, lastFlightDate, flightPlan, j, flightSegments);
                    flights.Add(flight);
                }
            }
            // If the user asked for external flights
            if (isExternal)
            {
                await RunExternalFlights(relative_to, flights);
            }
            return flights;
        }
        private Flight CreateFlight
            (DateTime relativeDate, DateTime lastFlightDate,
            KeyValuePair<string, FlightPlan> flightPlan,
            int numSeg, List<Segment> flightSegments)
        {
            double longitude1 = 0, longitude2, latitude1 = 0, latitude2, longitude3, latitude3;
            double secoInSegment, timeRatio, distance, midDistance;
            // Find how much time passed from segment till now.
            secoInSegment = relativeDate.Subtract(lastFlightDate).TotalSeconds;
            // Find the time ratio.
            timeRatio = secoInSegment / flightSegments[numSeg - 1].Timespan_Seconds;
            // Check if we are in the first segment.
            if (numSeg == 1)
            {
                // The last coordinate is from Initial_Location.
                longitude1 = flightPlan.Value.Initial_Location.Longitude;
                latitude1 = flightPlan.Value.Initial_Location.Latitude;
            }
            else
            {
                // The last coordinate is from last segment.
                longitude1 = flightSegments[numSeg - 2].Longitude;
                latitude1 = flightSegments[numSeg - 2].Latitude;
            }
            // The current segment's coordinates.
            longitude2 = flightSegments[numSeg - 1].Longitude;
            latitude2 = flightSegments[numSeg - 1].Latitude;
            // Linear interpolation
            distance = Math.Sqrt((Math.Pow(longitude2 - longitude1, 2)
                + Math.Pow(latitude2 - latitude1, 2)));
            midDistance = timeRatio * distance;
            latitude3 = latitude2 - ((midDistance) * (latitude2 - latitude1) / distance);
            longitude3 = longitude2 - ((midDistance) * (longitude2 - longitude1) / distance);
            // Create new Flight with the details we found.
            Flight flight = new Flight();
            flight.Longitude = longitude3;
            flight.Latitude = latitude3;
            flight.Flight_Id = flightPlan.Key;
            flight.Is_External = false;
            flight.Company_Name = flightPlan.Value.Company_Name;
            flight.Passengers = flightPlan.Value.Passengers;
            flight.Date_Time = flightPlan.Value.Initial_Location.Date_Time;
            db.fDictionary.TryAdd(flight.Flight_Id, flight);
            return flight;
        }
        public async Task<List<Flight>> RunExternalFlights
            (string relative_to, List<Flight> flights)
        {
            // Go over all servers
            foreach (KeyValuePair<string, Server> server in db.serverDictionary)
            {
                if (server.Value.ServerURL == "https://localhost:44308")
                {
                    continue;
                }
                string request = server.Value.ServerURL + "/api/Flights?relative_to=" + relative_to;
                List<Flight> serverFlights = await GetFlightsFromServer(request);
                // If the server has no FlightPlan in this relative time.
                if (serverFlights == null)
                {
                    continue;
                }
                // Go over all Flights.
                foreach (Flight flight in serverFlights)
                {
                    // Change this field to true.
                    flight.Is_External = true;
                }
                // Go over all Flights.
                //foreach (Flight flight in flights)
                //{
                //    // Change this field to true.
                //    flight.Is_External = true;
                //}
                // Add them to list.
                flights.AddRange(serverFlights);
            }
            return flights;
        }

        protected async Task<List<Flight>> GetFlightsFromServer(string url)
        {
            string strResult = await SendRequestToServer(url);
            List<Flight> serverFlights;
            // Try to deserialize the jason to list of Flight.
            try
            {
                serverFlights = JsonConvert.DeserializeObject<List<Flight>>(strResult);
            } catch {
                // If it failed- return null.
                return null;
            }
            return serverFlights;

        }
        protected async Task<string> SendRequestToServer(string url)
        {
            // Create the request.
            string strurl = string.Format(url);
            WebRequest requestObjGet = WebRequest.Create(strurl);
            requestObjGet.Method = "GET";
            HttpWebResponse responseObjGet = null;
            // Get the response from server.
            responseObjGet = (HttpWebResponse)await requestObjGet.GetResponseAsync();

            // Return response to string (json).
            string strResult = null;
            using (Stream stream = responseObjGet.GetResponseStream())
            {
                StreamReader sr = new StreamReader(stream);
                strResult = sr.ReadToEnd();
                sr.Close();
            }
            return strResult;
        }

        public async Task<FlightPlan> GetFlightPlanById(string id)
        {
            // Check if this flight is internal.
            if (db.fpDictionary.ContainsKey(id))
            {
                return db.fpDictionary[id];
            }
            // Go over all external servers.
            foreach (KeyValuePair<string, Server> server in db.serverDictionary)
            {
                // Send request to this server.
                string request = server.Value.ServerURL + "/api/FlightPlan/" + id;
                FlightPlan serverFlightPlan = await GetFlightPlanFromServer(request);
                // check if there is more effective check!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                // Check if this flight exist in this server.
                if (serverFlightPlan.Company_Name != null)
                {
                    return serverFlightPlan;
                }
            }
            // There is no FlightPlan with this id (internal and external).
            return null;
        }

        private async Task<FlightPlan> GetFlightPlanFromServer(string url)
        {
            string strResult = await SendRequestToServer(url);
            // Deserialize the json to FlightPlan object.
            FlightPlan flightPlan = JsonConvert.DeserializeObject<FlightPlan>(strResult);
            return flightPlan;
        }
        public FlightPlan AddFlightPlan(FlightPlan flightPlan)
        { 
            // Create id to the new FlightPlan.
            string id = fm.GenerateId();
            flightPlan.Id = id;
            // Add to FlightPlan dictionary.
            db.fpDictionary.Add(id, flightPlan);

            return flightPlan;
        }

        public void DeleteFlight(string  id)
        {
            //remove Flight Plan by id.
            FlightPlan flightPlan = db.fpDictionary[id];
            db.fpDictionary.Remove(id,out flightPlan);
            //remove Flight by id.
            //Flight flight = DataBase.fDictionary[id];
            //DataBase.fDictionary.Remove(id, out flight);
        }
        public List<Server> GetAllServer()
        {
            // Create list of servers from the dictionary.
            List<Server> servers = new List<Server>();
            foreach (KeyValuePair<string, Server> server in db.serverDictionary)
            {
                servers.Add(server.Value);
            }
            return servers;
        }
        public void AddServer(Server s)
        {
            db.serverDictionary.TryAdd(s.ServerId,s);
        }
        public void DeleteServerByID(string  id)
        {
            // Find the server with this id and delete him.
            Server server = db.serverDictionary[id];
            db.serverDictionary.Remove(id, out server);
        }
    }
}