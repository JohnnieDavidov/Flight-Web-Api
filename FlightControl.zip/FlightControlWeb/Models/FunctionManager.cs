﻿using FlightControlWeb.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    public class FunctionManager : IFunctionManager
    {
        public string GenerateId()
        {
            string id = "";
            Random rnd = new Random();
            id += Convert.ToChar(rnd.Next(65, 91));
            id += Convert.ToChar(rnd.Next(65, 91));
            id += Convert.ToChar(rnd.Next(97, 123));
            id += Convert.ToChar(rnd.Next(97, 123));
            for (int i = 0; i < 4; i++)
            {
                id += rnd.Next(0, 10);
            }
            return id; // return the id
        }

        public Flight createFlight(FlightPlan fp)
        {
            List<Segment> segments = fp.Segments;
            int j = 0;
            fp.lastFlightDate = TimeZoneInfo.ConvertTimeToUtc(Convert.ToDateTime(fp.Initial_Location.Date_Time));
            fp.flightDate = TimeZoneInfo.ConvertTimeToUtc(Convert.ToDateTime(fp.Initial_Location.Date_Time));
            while ((fp.flightDate <= fp.relativeDate) && (j < segments.Count))
            {
                fp.lastFlightDate = fp.flightDate;
                // Each time- add the timespan seconds of the segments.
                fp.flightDate = fp.flightDate.AddSeconds(segments[j].Timespan_Seconds);
                j++;
            }
            double longitude1 = 0, longitude2, latitude1 = 0, latitude2, longitude3, latitude3;
            double secoInSegment, timeRatio, distance, midDistance;
            // Find how much time passed from segment till now.
            secoInSegment = fp.relativeDate.Subtract(fp.lastFlightDate).TotalSeconds;
            // Find the time ratio.
            timeRatio = secoInSegment / (double)segments[j - 1].Timespan_Seconds;
            // Check if we are in the first segment.
            if (j == 1)
            {
                // The last coordinate is from Initial_Location.
                longitude1 = fp.Initial_Location.Longitude;
                latitude1 = fp.Initial_Location.Latitude;
            }
            else
            {
                // The last coordinate is from last segment.
                longitude1 = segments[j - 2].Longitude;
                latitude1 = segments[j - 2].Latitude;
            }
            // The current segment's coordinates.
            longitude2 = segments[j - 1].Longitude;
            latitude2 = segments[j - 1].Latitude;
            // Linear interpolation
            distance = Math.Sqrt((Math.Pow(longitude2 - longitude1, 2)
                + Math.Pow(latitude2 - latitude1, 2)));
            midDistance = timeRatio * distance;
            latitude3 = latitude2 - ((midDistance) * (latitude2 - latitude1) / distance);
            longitude3 = longitude2 - ((midDistance) * (longitude2 - longitude1) / distance);
            // Create new Flight with the details we found.
            Flight flight = new Flight();
            flight.Longitude = longitude3;
            flight.Latitude = latitude3;
            flight.Flight_Id = fp.Id;
            flight.Is_External = false;
            flight.Company_Name = fp.Company_Name;
            flight.Passengers = fp.Passengers;
            flight.Date_Time = fp.Initial_Location.Date_Time;
            //DataBase.fDictionary.TryAdd(flight.Flight_Id, flight);
            return flight;
        }
    }
}
